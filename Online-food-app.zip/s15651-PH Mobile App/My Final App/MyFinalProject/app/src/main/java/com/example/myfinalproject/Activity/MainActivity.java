package com.example.myfinalproject.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myfinalproject.Adapter.FoodListAdapter;
import com.example.myfinalproject.Domain.FoodDomain;
import com.example.myfinalproject.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapterFoodList;
    private RecyclerView recyclerViewFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRecyclerview();
        bottomNavigation();

        
        
    }

    private void bottomNavigation() {
        LinearLayout homeBtn=findViewById(R.id.homeBtn);
        LinearLayout cartBtn=findViewById(R.id.cartBtn);
        LinearLayout settingBtn=findViewById(R.id.settingBtn);
        LinearLayout supportBtn=findViewById(R.id.supportBtn);

        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,MainActivity.class));
            }
        });
        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,CartActivity.class));
            }
        });
        settingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,SettingActivity.class));
            }
        });
        supportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String packageName = "com.example.finalsupport";
                String className = "com.example.finalsupport.MainActivity";

                Intent intent = new Intent();
                intent.setComponent(new ComponentName(packageName, className));

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    // Handle the case where the support app is not installed
                    Toast.makeText(MainActivity.this, "The support app is not installed.", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }

    private void initRecyclerview() {
        ArrayList<FoodDomain> items=new ArrayList<>();
        items.add(new FoodDomain("Chese Burger","Savor the deliciousness of our university canteen's cheeseburger, " +
                "\nfeaturing a succulent beef patty, perfectly melted cheese, and fresh toppings, all nestled in a soft bun. " +
                "\nElevate your lunchtime with this satisfying classic that's sure to fuel your day of studies and activities." +
                " \nBite into comfort and flavor with every mouthwatering bite of our cheeseburger special.","fast_1",250,20,150,4.5));
        items.add(new FoodDomain("BBQ Pizza","Indulge in a flavorful experience with our university canteen's BBQ pizza, boasting a smoky" +
                "\n fusion of tangy barbecue sauce, savory toppings, and melted cheese on a crispy crust." +
                "\n Elevate your taste buds with this unique twist on a beloved classic, right here on campus.","fast_2",350,15,200,4.8));
        items.add(new FoodDomain("Vegetable Pizza","Savor a burst of freshness with our university canteen's vegetable pizza, topped with a" +
                "\n colorful medley of farm-fresh veggies on a delectably crispy crust—an invigorating choice" +
                "\n for a wholesome and satisfying meal on campus.","fast_3",200,25,120,4.2));
        items.add(new FoodDomain("Chicken Bucket","Delicious fried chicken served in a crispy bucket, " +
                "\na perfect grab-and-go option at the university canteen.","fast_4",400,15,200,4.9));
        items.add(new FoodDomain("Chicken Kothhu","Savor the flavors of our savory chicken kothu," +
                "\n a delectable fusion of spices and tender chicken pieces, " +
                "\nright at your university canteen.","fast_5",250,20,120,4.5));
        items.add(new FoodDomain("Rice & Curry","Enjoy a hearty meal with our daily special rice and curry," +
                "\n a satisfying and flavorful option at the university canteen.","fast_6",150,10,150,4.8));
        items.add(new FoodDomain("Apple Juice","Stay refreshed and energized with our crisp and pure apple juice," +
                "\n a healthy choice available at your university canteen.","fast_7",100,10,150,5.0));
        items.add(new FoodDomain("Avocado Juice","Indulge in a creamy and nutritious avocado juice," +
                "\n a refreshing pick-me-up option at your university canteen.","fast_8",100,10,150,4.9));

        recyclerViewFood=findViewById(R.id.view1);
        recyclerViewFood.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));

        adapterFoodList=new FoodListAdapter(items);
        recyclerViewFood.setAdapter(adapterFoodList);
    }
}