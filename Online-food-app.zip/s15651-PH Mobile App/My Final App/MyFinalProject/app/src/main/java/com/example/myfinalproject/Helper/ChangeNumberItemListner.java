package com.example.myfinalproject.Helper;

public interface ChangeNumberItemListner {
    void changed();
}
